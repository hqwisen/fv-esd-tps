#include <iostream.h>

class A {
 public:
   virtual void f (int i) { cout << "f (int) de A" << endl; }
   virtual void f () { cout << "f () de A" << endl; }
};

class B : public A {
 public:
   virtual void f () { cout << "f () de B" << endl; }
};

int main () {
/*
   B* pB = new B();
   pB->f();
   pB->f(1);

   A* pA = new B();
   pA->f();
   pA->f(1);
*/
}
